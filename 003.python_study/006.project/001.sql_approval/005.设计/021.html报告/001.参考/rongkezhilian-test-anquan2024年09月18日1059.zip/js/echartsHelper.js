var colorList = [ '#FF0000', '#fffc07', '#00B0F0', '#7cf00c', '#bfa5f0', '#f0cb26', '#11f0f0', '#72f0ac', '#f07de4','#f06e0c' ];
var stockColorList = [ '#06C639', '#7DFF53', '#fffc07' ];

function createSimplePie(data) {
    var chart = echarts.init(document.getElementById(data.id));
    var option = {
        title : {
            text : data.title,
            x : 'center'
        },
        tooltip : {
            trigger : 'item',
            formatter : "{b} : {c} ({d}%)"
        },
        // legend : {
        // 	orient : 'horizontal',
        // bottom: 1,
        // x : 'center',
        //     padding : 10,
        //     data : data.legend
        // },
        series : [ {
            type : 'pie',
            radius : '50%',
            center : [ '50%', '50%' ],
            data : data.series,
            itemStyle : {
                emphasis : {
                    shadowBlur : 10,
                    shadowOffsetX : 0,
                    shadowColor : 'rgba(0, 0, 0, 0.5)'
                },
                normal : {
                    color : function(params) {
                        if (data.color != null && data.color !== "") {
                            colorList = data.color;
                        }
                        return colorList[params.dataIndex]
                    },
                    label : {
                        show : true,
                        formatter : '{d}%',
                        color : '#0C0000'
                    },
                    labelLine : {
                        show : true
                    }
                }
            }
        } ]
    };
    chart.setOption(option);
}

function createPie(data) {
    var chart = echarts.init( document.getElementById(data.id));
    var option = {
        title : {
            text: data.title,
            x:'center'
        },
        tooltip : {
            trigger: 'item',
            formatter: "{b} : {c} ({d}%)"
        },
        legend: {
            orient : 'horizontal',
            bottom: 1,
            x : 'center',
            padding: 10,
            data: data.legend
        },
        series : [
            {
                type: 'pie',
                radius : '53%',
                center: ['50%', '50%'],
                data:data.series,
                itemStyle: {
                    emphasis: {
                        shadowBlur: 10,
                        shadowOffsetX: 0,
                        shadowColor: 'rgba(0, 0, 0, 0.5)'
                    },
                    normal: {
                        color: function (params) {
                            if(data.color != null && data.color !== ""){
                                colorList = data.color;
                            }
                            return colorList[params.dataIndex]
                        },
                        label:{
                            show: true,
                            formatter: '{d}%',
                            //position: 'inner',
                            color:'#0C0000'
                        },
                        labelLine :{show:true}
                    }
                }
            }
        ]
    };
    chart.setOption(option);
}

function createBar(data) {
    var width = 30;
    if(data.legend.length > 4){
        width += 4;
        width -= data.legend.length;
    }
    var chart = echarts.init(document.getElementById(data.id));
    var option = {
        title : {
            text : data.title,
            x : 'center'
        },
        tooltip : {
            show : "true",
            trigger : 'axis',
            axisPointer : {
                type : 'line',
                lineStyle : {
                    opacity : 0
                }
            },
            /* axisPointer : { // 坐标轴指示器，坐标轴触发有效
                type : 'shadow' // 默认为直线，可选为：'line' | 'shadow'
            } */
        },
        color:["#00B0F0"],
        xAxis : {
            type : 'category',
            data : data.legend,
            axisLabel : {
                interval : 0,
                rotate : 30
            }
        },

        yAxis : {
            type : 'value',
            minInterval : 1,
            boundaryGap : [ 0, 0.1 ]
        },
        series : [ {
            name: data.name,
            data : data.barSeries,
            barWidth : width,
            label : {
                normal : {
                    show : true,
                    position : 'top',
                    color : '#0C0000'
                }
            },
            type : 'bar'
        } ]
    };
    chart.setOption(option);
}

var changeDivHeight = function(data, expansion, width) {
    var temp = data.width + 2;
    width = typeof width !== 'undefined' ? width : temp;
    var div = $("#" + data.id);
    var len = data.yAxisData.length;
    var height = 100;
    height += (width+ 4) * expansion * (len+1);
    div.height(height);
};
function createComplexBar() {

    var groupriskChart = echarts.init(document
        .getElementById(data.id));
    var groupriskOption = {
        title : {
            text : data.title,
            x : 'center',
        },
        backgroundColor : '#EEF2F3',//背景色
        legend : data.legend,
        color : data.color,
        tooltip : {
            show : "true",
            trigger : 'axis',
            axisPointer : {
                type : 'line',
                lineStyle : {
                    opacity : 0
                }
            },
            axisPointer : { // 坐标轴指示器，坐标轴触发有效
                type : 'shadow' // 默认为直线，可选为：'line' | 'shadow'
            }
        },
        grid : {
            top:67,
            left : '3%',
            right : '14%',
            bottom : 30,
            containLabel : true
        },
        xAxis : [ {
            type : 'value',
            position : 'top',
            minInterval : 1,
            boundaryGap : [ 0, 0.1 ]
        } ],
        yAxis : [ {
            type : 'category',
            data : data.yAxisData,
            inverse : true,
            axisTick : {
                alignWithLabel : true
            },
            axisLabel : {
                formatter : '{value}'
            }
        } ],
        series : data.series
    };
    groupriskChart.setOption(groupriskOption, true);
}


function createSimpleBar(data) {
    var chart = echarts.init(document.getElementById(data.id));
    var option = {
        title : {
            text : data.title,
            x : 'center'
        },
        tooltip : {
            show : "true",
            trigger : 'axis',
            axisPointer : {
                type : 'line',
                lineStyle : {
                    opacity : 0
                }
            }
            /* axisPointer : { // 坐标轴指示器，坐标轴触发有效
                type : 'shadow' // 默认为直线，可选为：'line' | 'shadow'
            } */
        },
        xAxis : {
            type : 'category',
            data : data.legend,
            axisLabel : {
                interval : 0,
                rotate : -30
            }
        },
        yAxis : {
            type : 'value',
            minInterval : 1,
            boundaryGap : [ 0, 0.1 ]
        },
        series : [ {
            data : data.barSeries,
            barWidth : 30,
            itemStyle : {
                normal : {
                    color : function(params) {
                        if (data.color != null && data.color !== "") {
                            colorList = data.color;
                        }
                        return colorList[params.dataIndex]
                    }
                }
            },
            label : {
                normal : {
                    show : true,
                    position : 'top',
                    color : '#0C0000'
                }
            },
            type : 'bar'
        } ]
    };
    chart.setOption(option);
}
function createBackSimpleBar(data) {
    var chart = echarts.init(document.getElementById(data.id));
    var option = {
        title : {
            text : data.title,
            x : 'center'
        },
        xAxis : {
            type : 'value',
            position : 'top'
        },
        yAxis : {
            type : 'category',
            data : data.legend
        },
        series : [ {
            data : data.barSeries,
            barWidth : 30,
            itemStyle : {
                normal : {
                    color : function(params) {
                        return colorList[params.dataIndex]
                    }
                }
            },
            label : {
                normal : {
                    show : true,
                    position : 'right',
                    color : '#0C0000'
                }
            },
            type : 'bar'
        } ]
    };
    chart.setOption(option);
}
var autoDiv = function(data, expansion, width) {
    width = typeof width !== 'undefined' ? width : 50;
    var div = $("#" + data.id);
    var len = data.yAxisData.length;
    if (len > 5) {
        var height = div.height();
        height += width * expansion * (len - 5);
        div.height(height);
    }
};
function createSeriesBar(data) {
    autoDiv(data, data.series.length);
    var series = [];
    for (var i = 0; i < data.series.length; i++) {
        var ser = {
            name : data.series[i].name,
            data : data.series[i].v,
            label : {
                normal : {
                    show : true,
                    position : 'right',
                    color : '#0C0000'
                }
            },
            type : 'bar',
            barWidth : 15
        };
        series.push(ser);
    }
    var splice = 0;
    if (data.legend.length > 3) {
        splice = data.legend.length / 2;
    }
    if (data.legend.length === 3) {
        splice = 2;
    }
    data.legend.splice(splice, 0, '');

    var option = {
        title : {
            text : data.title,
            x : 'center'
        },
        legend : {
            left : 'right',
            data : data.legend
        },
        grid : {
            top:67,
            left : '3%',
            right : '14%',
            bottom : '8%',
            containLabel : true
        },
        color : colorList,
        xAxis : {
            type : 'value',
            position : 'top',
            minInterval : 1,
            boundaryGap : [ 0, 0.1 ]
        },
        yAxis : {
            type : 'category',
            data : data.yAxisData,
            minInterval : 1,
            boundaryGap : [ 0, 0.1 ]
        },
        series : series
    };
    var chart = echarts.init(document.getElementById(data.id));
    chart.setOption(option);
}
function createStockBar(data) {
    autoDiv(data, 1, 30);
    var series = [];
    for (var i = 0; i < data.series.length; i++) {
        var ser = {
            name : data.series[i].name,
            data : data.series[i].v,
            stack : '总量',
            label : {
                normal : {
                    show : false,
                    position : 'insideLeft',
                    color : '#0C0000'
                }
            },
            type : 'bar'
        };
        if (data.series.length <= 5) {
            ser.barWidth = 30;
        }
        series.push(ser);
    }
    if (data.legend.length > 3) {
        data.legend.splice(data.legend.length / 2, 0, '')
    }
    var chart = echarts.init(document.getElementById(data.id));
    var option = {
        title : {
            text : data.title,
            x : 'center'
        },
        legend : {
            left : 'right',
            data : data.legend
        },
        grid : {
            top:67,
            left : '3%',
            right : '14%',
            bottom : '8%',
            containLabel : true
        },
        tooltip : {
            trigger : 'axis',
            axisPointer : {
                type : 'shadow'
            },
            formatter : "{b} : <span style='color:#06C639 '>{c0}</span>/ <span style='color:#7DFF53 '>{c1}</span>/ <span style='color:#fffc07 '>{c2}</span> "
        },
        color : stockColorList,
        xAxis : {
            type : 'value',
            position : 'top',
            minInterval : 1,
            boundaryGap : [ 0, 0.1 ]
        },
        yAxis : {
            type : 'category',
            data : data.yAxisData

        },
        series : series
    };
    chart.setOption(option);
}
// window.onresize = function(ev) {
//     window.location.reload();
// }